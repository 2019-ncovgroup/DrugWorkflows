#!/bin/bash
pymol Nsp10_Nsp16_CX_inPDB.pml
