#!/bin/bash
vmd Nsp10_Nsp16_CX_inPDB_out.pdb -e Nsp10_Nsp16_CX_inPDB.tcl
